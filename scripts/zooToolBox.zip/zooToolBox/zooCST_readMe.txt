To install zooCST, copy all the scripts to your scripts directory (the scripts directory should be listed in your scripts_path environment variable), and all the icons to your icons directory.  To make the right click menus work, please rename the appropriate dagMenuProc_v*.mel script.  See the zooTriggered_readme.txt file for more information on how to do that.

Ie if you're using maya version 7, rename dagMenuProc_v7.mel to dagMenuProc.mel
and if you're using maya version 8, rename dagMenuProc_v8.mel to dagMenuProc.mel

To run the script, type zooCST.  Once the zooCST UI has loaded, you may install a shelf button to the script using the "Tools" menu.  For more information about how zooCST works, check out the help menu.  If you have an trouble using this script, or just want to contribute some feedback, you can contact the author at:  hamish@macaronikazoo.com

provided with the zooCST distribution is a primitive character (primoBoy!) that you can quickly rig up using zooCST to get a quick idea of what zooCST can do - or just to animate with.

Happy Rigging!
-zoo