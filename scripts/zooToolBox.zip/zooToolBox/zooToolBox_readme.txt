Welcome to the zooToolBox package!  Inside you will find a collection of all the zoo scripts in active distribution.  To install the package, simply copy both the sub-folders in the arcive to your "my documents/maya/" folder.  This should put all the scripts in the right place, and the icons in the right place.  Then fire up maya and run:  zooToolBox;  in your script editor.

This will open up the zooToolBox interface.  From there you can browse the help, and explore the contents of the package through maya.
enjoy!
-zoo.